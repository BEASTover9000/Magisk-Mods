#!/system/bin/sh

MODDIR=${0%/*}

echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo 0 > /sys/module/msm_performance/parameters/touchboost

for i in /sys/class/kgsl/kgsl-3d0 ; do

	echo 0 > $i/thermal_pwrlevel
    echo 0 > $i/throttling 
    echo 0 > $i/max_pwrlevel
    echo 0 > $i/perfcounter
    echo 1 > $i/force_clk_on
    echo 0 > $i/force_bus_on
    echo 1 > $i/force_rail_on
    echo 1 > $i/force_no_nap
    echo 1 > $i/bus_split

done;

exit 0