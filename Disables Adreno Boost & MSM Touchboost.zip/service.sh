#!/system/bin/sh

MODDIR=${0%/*}

sleep 5
echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo 0 > /sys/module/msm_performance/parameters/touchboost
exit 0
