#!/system/bin/sh

MODDIR=${0%/*}

sleep 5
echo 762 > /sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq
echo 7980 > /sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
echo 2288 > /sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/min_freq
echo 15258 > /sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/max_freq

chmod 0444 /sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq
chmod 0444 /sys/class/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
chmod 0444 /sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/min_freq 
chmod 0444 /sys/class/devfreq/soc:qcom,cpu-cpu-llcc-bw/max_freq

chmod 0644 /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu0-cpu-l3-lat/min_freq
chmod 0644 /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu4-cpu-l3-lat/min_freq
chmod 0644 /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu7-cpu-l3-lat/min_freq

echo 1612800000 > /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu0-cpu-l3-lat/min_freq
echo 1612800000 > /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu4-cpu-l3-lat/min_freq
echo 1612800000 > /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu7-cpu-l3-lat/min_freq

chmod 0444 /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu0-cpu-l3-lat/min_freq
chmod 0444 /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu4-cpu-l3-lat/min_freq
chmod 0444 /sys/class/devfreq/18590000.qcom,devfreq-l3:qcom,cpu7-cpu-l3-lat/min_freq 
exit 0